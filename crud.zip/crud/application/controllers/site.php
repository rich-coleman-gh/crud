<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {
	public function index() {
		$value = array();
		if($data = $this->model_site->read_record()) {
			$value['record'] = $data;
		}
		$this->load->view('home', $value);
	}

	function create() {
		$data =array('username' => $this->input->post('username')
			,'password' => $this->input->post('password')
			,'email' => $this->input->post('email'));

		if (!empty($data['username']) && !empty($data['password']) && !empty($data['email'])) {
			$this->model_site->add_record($data);
		}
		else {
			echo "Please make sure all fields are filled in";
		}
		$this->index();
	}

	function delete() {
		$this->model_site->delete_record();
		$this->index();
	}

	function edit() {
		$value = array();
		if($data = $this->model_site->edit_record()) {
			$value['record'] = $data;
		}
		$this->load->view('edit',$value);
	}

	function update() {
		$data =array('id' => $this->input->post('id')
			,'username' => $this->input->post('username')
			,'password' => $this->input->post('password')
			,'email' => $this->input->post('email'));

		if (!empty($data['username']) && !empty($data['password']) && !empty($data['email'])) {
			$this->model_site->update_record($data);
		}
		else {
			echo "Please make sure all fields are filled in";
		}
		$this->index();
	}
}