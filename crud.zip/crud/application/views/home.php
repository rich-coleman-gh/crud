<html>
<head>
	<title></title>
	<style type="text/css">
		label{display: block;}
	</style>
</head>
<body>
	<div>
		<?php echo form_open('site/create'); ?>
		<p>
			<label for="username"> Username </label>
			<input type="text" name="username" id="username">
		</p>
		<p>
			<label for="password">Password</label>
			<input type="text" name="password" id="password">
		</p>
		<p>
			<label for="email">Email</label>
			<input type="text" name="email" id="email">
		</p>
		<button id="submitbtn">Submit</button>
		<?php echo form_close(); ?>
	</div>

	<div>
		<?php foreach ($record as $value) { ?>
		<h4><span> <?php echo $value->username; ?> </span>
			<span> <?php echo anchor('site/delete/' .$value->id, 'Delete') ?></span>
			<span> <?php echo anchor('site/edit/' .$value->id, 'Edit') ?></span>
		</h4>
		<div> 
			<?php echo $value->password; ?>
		</div>
		<div> 
			<?php echo $value->email; ?>
		</div>
		<?php } ?>
	</div>
</body>
</html>
